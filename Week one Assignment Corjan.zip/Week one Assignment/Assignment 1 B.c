#Include <stdio.h>
// Initialises the variables and methods
void maxArrays(float A[],float B[]);
float arrayA[4];
float arrayB[6];
float arrayC[1];
int arrayAsize;
int arrayBsize;
float arrayMaxSize[1];
int main(void)
{
	ArrayA[] = {12,15,44,56};
	ArrayB[] = {43,12,753,6572,42,38,87};
	ArrayMax[0] = maxArrays(ArrayA[],arrayB[] // calls the method maxArrays and stores the maximum value in the the array ArrayMax 
}
// accepts arrays of different sizes and finds the largest value.
float maxArrays(float A[],float B[])
{
	float maxValue = A[0];
	arrayAsize = sizeof(A)/sizeof(A[0]);
	for(int i =0;i<arrayAsize;i++)
	{
		if(A[i]>maxValue){
			maxValue = A[i];
		}
	}
	arrayBsize = sizeof(B)/sizeof(B[0]);
	for(int j = 0;j<arrayBsize;j++)
	{
		if(B[j]>maxValue){
			maxValue = B[i]
		}
	
	}
	return maxValue
}